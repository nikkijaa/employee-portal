import { Col, Container, Row } from "react-bootstrap";



export default function Contact(){
    return(
        <Container>
            <Row>
                <Col>
                    <h2>Contact</h2>
                </Col>
            </Row>            
        </Container>
    );
}