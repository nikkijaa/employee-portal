import { Col, Container, Row } from "react-bootstrap";

export default function About(){
    return(
        <Container>
            <Row>
                <Col>
                    <h2>About</h2>
                </Col>
            </Row>            
        </Container>
    );
}